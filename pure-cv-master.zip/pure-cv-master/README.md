# pure-cv
> This HTML template is designed by [Hong Wang](https://github.com/H0NGWANG/).

[![pure-cv demo](https://github.com/H0NGWANG/pure-cv/blob/master/img/demo.jpg?raw=true)](https://h0ngwang.github.io/pure-cv/)

## License
This project is licensed under the [MIT license](https://github.com/H0NGWANG/pure-cv/blob/master/LICENSE).

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/H0NGWANG/pure-cv/blob/master/LICENSE)
