window.onload = function() {
    var contactform = document.getElementById('contact-form');
    contactform.setAttribute('action', '//formspree.io/' + 'name' +
        '@' + 'gmail' + '.' + 'com');
}
